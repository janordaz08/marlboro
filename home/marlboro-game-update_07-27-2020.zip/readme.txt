1. /home/home.html

changelog:

Updated "KEEP PLAYING FOR MORE POINTS!" to "PLAY AGAIN TOMORROW!"